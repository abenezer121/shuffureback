// const { addDispatcher, removeDispatcher } = require('../containers/dispatcherContainer')

module.exports = async (data, dispatcher, socket) => {
    // removeDispatcher({ dispatcherId: id })
}