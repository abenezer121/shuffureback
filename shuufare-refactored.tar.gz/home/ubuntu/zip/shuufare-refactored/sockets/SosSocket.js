module.exports = (socket) => {
  socket.join('sos')
}
